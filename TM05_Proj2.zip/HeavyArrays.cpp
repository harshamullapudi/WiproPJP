#include <bits/stdc++.h>
using namespace std;

void findType(int arr[3][3]){
    int a=arr[0][0]+ arr[0][2]+ arr[2][0]+ arr[2][2];
    int b=arr[0][1]+ arr[1][0]+ arr[1][2]+ arr[2][1];
    if(a>b){
        cout<<"1";
    }
    else if(a<b){
        cout<<"2";
    }
    else{
        cout<<"3";
    }
}
int main(){
    int arr[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    findType(arr);
}