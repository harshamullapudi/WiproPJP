#include <bits/stdc++.h>
using namespace std;
class Time{
private:
	int hour,min,sec;
public:
	Time():hour(0), min(0), sec(0){}
	Time(int h, int m, int s):hour(h),  min(m), sec(s){}
	int gethour(){return hour;};
	int getmin(){return min;};
	int getsec(){return sec;};
	void sethour(int h){
		hour=h;
	}
	void setmin(int m){
		min=m;
	}
	void setsec(int s){
		sec=s;
	}
	Time difference(Time t1);
	int compare(Time t1);
	void display(){
		cout<<hour<<": "<<min<<": "<<sec<<endl;
	}	

};
Time Time::difference(Time t1){
		Time temp;
		temp.hour=this->hour-t1.hour;
		temp.min=this->min-t1.min;
		temp.sec=this->sec-t1.sec;
		return temp;
	}
	int Time::compare(Time t1){
        if(this->hour==t1.hour && this->min==t1.min && this->sec==t1.sec){
        	return 1;
        }
        return 0;
	}
int main(){
	Time t(10,30,40);
	Time t1(2,20,30);
	t.display();
	t1.display();
	Time t2=t.difference(t1);
	t2.display();
	cout<<t.compare(t1);
	return 0;
}