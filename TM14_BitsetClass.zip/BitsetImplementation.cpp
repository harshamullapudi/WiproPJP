#include <bits/stdc++.h>
using namespace std;
class Bitset{
private:
	int *B;
	int n;
public:
	Bitset(int size){
		B=new int[size];
		n=size;
		for(int i=0;i<n;i++){
			B[i]=0;
		}
	}
	void setbit(int idx){
		B[idx]=1;
	}
	void setbit(int idx, int bitval){
		B[idx]=bitval;
	}
	void clearbit(int idx){
		B[idx]=0;
	}
	void togglebit(int idx){
		if(B[idx]==0){
			B[idx]=1;
		}
		else{
			B[idx]=0;
		}
	}
	void getbit(int idx){
		cout<<B[idx]<<endl;
	}
	void print(){
		for(int i=n-1;i>=0;i--){
			cout<<B[i]<<" ";
		}
		cout<<endl;
	}

};
int main(){
	Bitset bset(8);
	bset.setbit(3);
	bset.setbit(5);
	bset.setbit(7);
	bset.clearbit(5);
	bset.setbit(0,1);
	bset.togglebit(1);
	bset.getbit(3);
	bset.print();
	return 0;
}