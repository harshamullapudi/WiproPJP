#include <bits/stdc++.h>
using namespace std;
class Int{
private:
	int num;
public:
	Int():num(0){}
	Int(int n){
		num=n;
	}
	Int(Int &obj){
		this->num=obj.num;
	}
	void operator=(const Int &k){
		this->num=k.num;
	}
	Int operator++(int){
		Int temp;
		temp.num=num++;
		return temp;
	}
	Int operator++(){
		Int temp;
		temp.num=++num;
		return temp;
	}
	void operator+=(Int &k){
		this->num=this->num+k.num;
	}
	void operator-=(Int &k){
		this->num=this->num-k.num;
	}
	Int operator+(Int &k){
		Int temp;
		temp.num=this->num+k.num;
		return temp;
	}
	Int operator-(Int &k){
		Int temp;
		temp.num=this->num-k.num;
		return temp;
	}
	void display(){
		cout<<this->num<<endl;
	}
	friend istream &operator>>(istream &, Int &);
	friend ostream &operator<<(ostream &, Int &);

};
istream &operator>>(istream &in, Int &k){
	in>>k.num;
	return in;
}
ostream &operator<<(ostream &out, Int &k){
	out<<k.num;
	return out;
}
int main(){
	Int p(2);
	Int q(p);
    Int input;
    cout<<"Enter any integer: ";
    cin>>input;
    cout<<p<<endl;
    cout<<q<<endl;
    cout<<input<<endl;
    p++;
    cout<<p<<endl;
    q=p+input;
    cout<<q<<endl;
    input=q-p;
    cout<<input<<endl;
    input-=p;
    cout<<input<<endl;
    return 0;
}