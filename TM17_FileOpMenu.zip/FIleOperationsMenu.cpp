#include <bits/stdc++.h>
using namespace std;
struct publisher{
    char pub_name[50];
    int pub_id;
    int books_sold;
    float total_sale;
};
void WriteUsingfput(char* fname){
    FILE* fp;
    fp=fopen(fname, "a");
    if(fp==NULL){
        fp=fopen(fname, "w");
    }
    if(fp){
        char ch=getc(stdin);
        while(ch!=EOF){
            fputc(ch, fp);
            ch=getc(stdin);
        }
    }
    else{
        perror("Cannot open the file\n");
    }
    fclose(fp);
}
void ReadUsingfgetc(char* fname){
    FILE* fp;
    fp=fopen(fname, "r");
    if(fp){
        char ch=getc(fp);
        while(ch!=EOF){
            putc(ch, stdout);
            ch=getc(fp);
        }
    }
    else{
        perror("Cannot open the file\n");
    }
    fclose(fp);
}
void AddNamesUsingfputs(char* fname){
    FILE* fp;
    fp=fopen(fname, "a");
    char s[100];
    int n;
    if(fp==NULL){
        fp=fopen(fname, "w");
    }
    if(fp){
        cout<<"Enter the number of names you would like to enter: ";
        cin>>n;
        cin.ignore();
        for(int i=1;i<=n;i++){
            cout<<"Enter the name #"<<i<<" : ";
            cin.getline(s,100);
            fputs(s,fp);
            fputs("\n",fp);
        }
    }
    else{
        perror("Cannot open the file\n");
    }
    fclose(fp);
}
void ReadUsingfgets(char* fname){
    FILE* fp;
    fp=fopen(fname, "r");
    char st[100];
    if(fp){
        while(fgets(st,100,fp)){
            cout<<st;
        }
    }
    else{
        perror("Cannot open the file\n");
    }
    fclose(fp);
}
void WritePublisherData(char* pname){
    FILE* fp;
    int n;
    fp=fopen(pname, "a");
    if(fp==NULL){
        fp=fopen(pname, "w");
    }
    if(fp){
        cout<<"How many publishers records do you want to enter: ";
        cin>>n;
        cin.ignore();
        publisher p[n];
        for(int i=1;i<=n;i++){
            cout<<"Enter publisher #"<<i<<" name: ";
            cin.getline(p[i].pub_name,50);
            cout<<"Enter publisher #"<<i<<" ID: ";
            cin>>p[i].pub_id;
            cout<<"Enter publisher #"<<i<<" books sold count: ";
            cin>>p[i].books_sold;
            cout<<"Enter publisher #"<<i<<" total sale: ";
            cin>>p[i].total_sale;
            cin.ignore();
            fwrite(&p[i], sizeof(struct publisher), 1, fp);
        }
    }
    else{
        perror("Cannot open the file\n");
    }
    fclose(fp);
}
void ReadPublisherData(char* pname){
    FILE* fp;
    fp=fopen(pname, "r");
    int k=1;
    publisher p[100];
    if(fp){
        while(fread(&p[k], sizeof(struct publisher), 1, fp)){
            cout<<"Name of publisher #"<<k<<": "<<p[k].pub_name<<endl;
            cout<<"ID of publisher #"<<k<<": "<<p[k].pub_id<<endl;
            cout<<"Books sold count of publisher #"<<k<<": "<<p[k].books_sold<<endl;
            cout<<"Total sale of publisher #"<<k<<": "<<p[k].total_sale<<endl;
            cout<<"*******************************"<<endl;
            k++;
        }
        cout<<"Total Records Found: "<<k-1<<endl;
    }
    else{
        perror("Cannot open the file\n");
    }
    fclose(fp);
}
int main(){
    int choice;
    char fname[]="story.txt";
    char pname[]="publisher.txt";
    while(true){
        cout<<"========================================"<<endl;
        cout<<"**************** Menu ******************"<<endl;
        cout<<"========================================"<<endl;
        cout<<"1. Write Story using fputc\n2. Read story using fgetc\n3. Add names uisng fputs\n4. Read story using fgets\n5. Write Publisher data using fwrite\n6. Read publisher data Using fread\n7. Exit\n"<<endl;
		cout<<"Enter Your option (1...7):  ";
        cin>>choice;
        switch(choice){
            case 1:
            WriteUsingfput(fname);
            break;
            case 2:
            ReadUsingfgetc(fname);
            break;
            case 3:
            AddNamesUsingfputs(fname);
            break;
            case 4:
            ReadUsingfgets(fname);
            break;
            case 5:
            WritePublisherData(pname);
            break;
            case 6:
            ReadPublisherData(pname);
            break;
            case 7:
            exit(0);
            default:
            cout<<"Invalid choice. Try again"<<endl;
            break;
        }
    }
}