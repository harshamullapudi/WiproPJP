#include <bits/stdc++.h>
using namespace std;
void getBiggestSubString(string& s,int l){
    unordered_map<string,int> m;
    int n=s.size();
    if(n<l ||l==0 ){
        cout<<"Invalid Length of substring";
    }
    if(n==l){
        cout<<s;
    }
    for(int i=0;i<n-l;i++){
        string st=s.substr(i,l);
        m[st]++;
    }
    int max=0;
    for(auto i=m.begin();i!=m.end();i++ ){
        if(i->second>max){
            max=i->second;
        }
    }
    vector<string> v;
    for(int i=0;i<n-l;i++){
        string st=s.substr(i,l);
        if(m[st]==max){
            v.push_back(st);
            m[st]=0;
        }
    }
    if(v.size()==0){
        cout<<v[0];
    }
    else{
        for(int i=0;i<v.size()-1;i++){
            cout<<v[i]+":";
        }
        cout<<v[v.size()-1];
    }


}
int main(){
    string str;
    int l;
    cout<<"Enter Input: ";
    getline(cin,str);
    cin>>l;
    getBiggestSubString(str,l);
}