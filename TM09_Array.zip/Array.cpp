#include <bits/stdc++.h>
using namespace std;
int main(){
    int *A;
    int i=0;
    while(true){
        char ch;
        cin>>ch;
        switch(ch){
            case 'C':
               int n;
               cin>>n;
               A=(int*)malloc(n*sizeof(int));
               break;
            case 'A':
               int k;
               cin>>k;
               A[i++]=k;
               break;
            case 'D':
               A[i]=0;
               i--;
               break;
            case 'R':
               int index,value;
               cin>>index>>value;
               A[index]=value;
               break;
           case 'P':
               for(int k=0;k<i;k++){
                    cout<<A[k]<<" ";
                }
                cout<<endl;
                break;
           case 'E':
                free(A);
                exit(0);
        }
    
    }
    return 0;
}