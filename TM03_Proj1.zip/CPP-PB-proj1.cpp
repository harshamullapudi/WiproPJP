
#include <iostream>
#include<vector>
using namespace std;

int checkPrime(int n) {
    bool isPrime = 1;

    if (n == 0 || n == 1) {
        isPrime = 0;
    }
    else {
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) {
                isPrime = 0;
                break;
            }
        }
    }
    return isPrime;
}

void primeSum(int n){
    //int arr[n];
    vector<int> v1;
    //int j=0;
    int p,q;
    for(int i=2;i<n;i++){
        if(checkPrime(i)==1){
            v1.push_back(i);
        }
    }
    for(int i=0;i<v1.size();i++){
        for(int k=0;k<v1.size();k++){
            if(v1[i]+v1[k]==n){
                p=v1[i];
                q=v1[k];
                break;
            }
        }
    }
    cout<<n<<" "<<p<<" "<<q<<endl;
    
}

int main() {
    int x[4];
    cout<<"Enter numbers: "<<endl;
    for(int i=0;i<4;i++){
        cin>>x[i];
        
    }
    for(int i=0;i<4;i++){
        primeSum(x[i]);
    }
    

    return 0;
}
