#include <bits/stdc++.h>
using namespace std;
int main(){
    int flag=0;
    ifstream infile("sample.txt");
    ofstream even;
    ofstream odd;
    even.open("even.txt");
    odd.open("odd.txt");
    for(string line; getline(infile, line); ){
        if(flag==0){
            odd<<line<<endl;
            flag=1;
        }
        else{
            even<<line<<endl;
            flag=0;
        }

    }
    even.close();
    odd.close();
    return 0;
}
