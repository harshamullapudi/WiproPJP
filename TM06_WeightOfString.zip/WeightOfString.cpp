#include<bits/stdc++.h>
using namespace std;
bool isVowel(char ch){
    if(ch=='a'||ch=='A'||ch=='e'||ch=='E'||ch=='i'||ch=='I'||ch=='o'||ch=='O'||ch=='u'||ch=='U'){
        return true;
    }
    return  false;
}
int weightOfString(char* s,int n){
    int sum=0;
    int i=0;
    if (n==0){
       while(s[i]){
            int ch=s[i];
            if(ch>=65 && ch<=90 && !isVowel(s[i])){
                sum+=(ch-'A'+1);
            }
            if(ch>=97 && ch<=122 && !isVowel(s[i])){
                sum+=(ch-'a'+1);
            }
            i++;
        }
    }
    else if(n==1) {
        
        while(s[i]){
            int ch=s[i];
            if((ch>=65 && ch<=90)){
                sum+=(ch-'A'+1);
            }
            if((ch>=97 && ch<=122)){
                sum+=(ch-'a'+1);
            }
            i++;
        }
    }
    
    return sum;
}
int main(){
    char str[100];
    int num;
    cout<<"Enter input1: ";
    cin.getline(str,100);
    cout<<"Enter input2: ";
    cin>>num;
    int p=weightOfString(str,(int)num);
    cout<<p<<endl;

}