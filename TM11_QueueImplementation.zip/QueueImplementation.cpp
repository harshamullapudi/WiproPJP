#include <bits/stdc++.h>
using namespace std;
#define N 10
class Queue{
private:
	int *q;
	int cap, count, front, rear;
public:
	Queue(){
		int size=N;
		q=new int[size];
		cap=size;
		count=0;
		front=0;
		rear=-1;
	}
	Queue(int size){
		q=new int[size];
		cap=size;
		count=0;
		front=0;
		rear=-1;
	}
	~Queue(){delete q;}
	void add(int element);
	void remove();
	int size(){
		return count;
	}
	int getfront(){
		if(isEmpty()){
			cout<<"queue is empty"<<endl;
		}
	    return q[front];
	}
	int isFull(){
		if(size()==cap){
			return 1;
		}
		return 0;
	}
	int isEmpty(){
		if(size()==0){
			return 1;
		}
		return 0;
	}
	void display(){
		for(int i=0;i<sizeof(q);i++){
			cout<<q[i]<<" ";
		}
		cout<<endl;
	}

};
void Queue::add(int element){
    if(isFull()){
    	cout<<"Queue is full"<<endl;
    }
    else{
        rear=(rear+1)%cap;
        q[rear]=element;
        count++;
    }

}
void Queue::remove(){
		if(isEmpty()){
			cout<<"Queue is empty"<<endl;
		}
		else{
		   cout<<q[front]<<endl;
		   front=(front+1)%cap;
		   count--;
	    }
}
int main(){
	Queue q1;
	q1.add(5);
	q1.add(10);
	q1.add(15);
	q1.remove();
	q1.remove();
	q1.add(30);
	q1.add(37);
	q1.remove();
	q1.remove();
	q1.remove();
	q1.remove();
	q1.add(45);
	q1.remove();
	q1.remove();
}