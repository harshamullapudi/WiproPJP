#include <bits/stdc++.h>
using namespace std;
struct EMP{
    string emp_name;
    int emp_id;
    EMP *next, *prev;
};
struct EMP* head=NULL;
struct EMP* tail=NULL;
struct EMP* CreateNode(string name, int id){
    EMP* temp=new EMP;
    temp->emp_name=name;
    temp->emp_id=id;
    temp->prev=NULL;
    temp->next=NULL;
    return temp;
}
int AddNode(){
    struct EMP* temp;
    string name;
    int id;
    cin.ignore();
    cout<<"Enter Employee Name: ";
    getline(cin,name);
    cout<<"Enter Employee ID: ";
    cin>>id;
    temp=CreateNode(name, id);
    if(head==NULL &&head==tail){
        head=tail=temp;
        head->next=tail->next=NULL;
        head->prev=tail->prev=NULL;
        return 1;
    }
    else{
        tail->next=temp;
        temp->prev=tail;
        tail=temp;
        tail->next=NULL;
        head->prev=NULL;
        return 2;
    }

}
void DisplayList(){
    cout<<"LINKED LIST DISPLAY"<<endl;
    cout<<"==================="<<endl;
    EMP* temp=head;

    while(temp!=tail){
        cout<<"Employee Name: "<<temp->emp_name<<endl;
        cout<<"EMployee ID: "<<temp->emp_id<<endl;
        temp=temp->next;
        cout<<endl;
    }
    if(temp!=NULL){
    cout<<"Employee Name: "<<temp->emp_name<<endl;
    cout<<"EMployee ID: "<<temp->emp_id<<endl;
    cout<<endl;
    }
    else{
        cout<<"List is Empty"<<endl;
    }
}
void CleanUp(){
    while(head!=tail){
        EMP* temp=head;
        head=head->next;
        free(temp);
    }
    free(head);
    head=tail=NULL;
}
int SearchNode(){
    int id;
    cout<<"Enter Employee ID to search: ";
    cin>>id;
    EMP* temp=head;
    while(temp!=tail){
        if(temp->emp_id==id)
        {
            cout<<"Name of the Employee is: "<<temp->emp_name<<endl;
            return 1;
        }
        temp=temp->next;
    }
    if(temp->emp_id==id)
    {
        cout<<"Name of the Employee is: "<<temp->emp_name<<endl;
        return 1;
    }
    return 0;
}
int DeleteNode(){
    int id;
    cout<<"Enter the ID of the employee to be deleted: ";
    cin>>id;
    if(head==NULL && head==tail){
        return 0;
    }
    EMP* temp;
    EMP* k;
    if(head->emp_id==id){
        temp=head;
        head=head->next;
        head->prev=NULL;
        free(temp);
        return 1;
    }
    else if(tail->emp_id==id){
        temp=tail;
        tail=tail->prev;
        tail->next=NULL;
        free(temp);
        return 3;
    }
    else{
        k=head->next;
        while(k!=tail){
            if(k->emp_id==id){
                temp=k;
                k=k->next;
                k->prev=temp->prev;
                temp->prev->next=k;
                free(temp);
                return 2;
            }
            k=k->next;
        }
    }
    return 0;
}
int main(){
    int choice;
    while(true){
        cout<<"============================"<<endl;
        cout<<"******* Main Menu **********"<<endl;
        cout<<"============================"<<endl;
        cout<<"1. Add Node\n2. Delete Node\n3. Search Node\n4. Display List\n5. CleanUp\n6. Exit\n"<<endl;
		cout<<"Enter Your option (1...6):  ";
        cin>>choice;
        int n;
        switch(choice){
         case 1:
            n=AddNode();
            if(n==1){
                cout<<"Head node added."<<endl;
            }
            else if(n==2){
                cout<<"Non-head Node added."<<endl;
            }
            break;
         case 2:
            n=DeleteNode();
            if(n==0){
                cout<<"Node to be deleted not found!!"<<endl;
            }
            if(n==1){
                cout<<"Deleted head Node"<<endl;
            }
            if(n==2){
                cout<<"Deleted one of the middle Nodes"<<endl;
            }
            if(n==3){
                cout<<"Deleted tail Node"<<endl;
            }
            break;
         case 3:
            n=SearchNode();
            if(n==0){
                cout<<"Node not found"<<endl;	
            }
            else{
                cout<<"Node found and content displayed"<<endl;
            }
            break;
         case 4:
            DisplayList();
            break;
         case 5:
            CleanUp();
            break;
         case 6:
            CleanUp();
            exit(0);
         default:
            cout<<"Invalid choice. Try again"<<endl;
            break;
        }
    }
    return 0;
}