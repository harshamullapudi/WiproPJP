#include <bits/stdc++.h>
using namespace std;
class Stack{
    private:
    string* arrstr;
    int tops;
    int stackSize;
    public:
    Stack(int n){
        arrstr=new string[n];
        tops=-1;
        stackSize=n;
    }
    void push(const string& s);
    void pop(string& s);
    void top(string& s);
    bool isEmpty();
    bool isFull();
    ~Stack(){
        delete[] arrstr;
    }
};
bool Stack::isEmpty(){
    if(tops>=0) return false;
    return true;
}
bool Stack::isFull(){
    if(tops==stackSize-1) return true;
    return false;
}
void Stack::push(const string& s){
    if(isFull()){
        throw out_of_range("Stack<>::pop(): full stack"); 
    }
    else{
        tops+=1;
        arrstr[tops]=s;
    }
}
void Stack::pop(string& s){
    if(isEmpty()){
        throw out_of_range("Stack<>::pop(): empty stack"); 
    }
    else{
        s=arrstr[tops];
        tops-=1;
        cout<<"Element popped: "<<s<<endl;
    }
}
void Stack::top(string& s){
    if(isEmpty()){
        throw out_of_range("Stack<>::pop(): empty stack"); 
    }
    else{
        s=arrstr[tops];
        cout<<"Top Element: "<<s<<endl;
    }
}
int main(){
    Stack S(5);
    string s;
    try{
        S.push("begin");
        S.push("end");
        S.top(s);
        S.pop(s);
        S.top(s);
        S.pop(s);
        S.pop(s);
    }
    catch(exception const& e){
        cout<<"Exception thrown: "<<e.what()<<endl;
    }
}