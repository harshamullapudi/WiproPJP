#include <bits/stdc++.h>
using namespace std;
int main(int args, char* argv[]){
    string st=" ";
    int i=1;
    if(args==4){
        st=argv[1][2];
        i++;
    }
    ifstream f1(argv[i]);
    i++;
    ifstream f2(argv[i]);
    string line;
    while(!f1.eof()){
        getline(f1,line);
        cout<<line;
        cout<<st;
        if(!f2.eof()){
            getline(f2,line);
            cout<<line;
        }
        cout<<endl;
    }
    return 0;

}