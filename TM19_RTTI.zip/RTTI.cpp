#include <bits/stdc++.h>
using namespace std;
namespace ns1{
    int same;
    int diff1;
    int diff2;
    void check(int p, int q, int r){
        same=p;
        diff1=q;
        diff2=r;
    }
}
namespace ns2{
    int same;
    int diff01;
    int diff02;
    void check(int p, int q, int r){
        same=p;
        diff01=q;
        diff02=r;
    }
}
class Country{
    public:
    string cname;
    Country(string cn):cname(cn){};
    virtual void display(){
        cout<<"Country name is "<<cname<<endl;
    }
};
class State: public Country{
    public:
    string sname;
    State(string cn, string sn):Country(cn),sname(sn){};
    virtual void display(){
        cout<<"State name is "<<sname<<endl;
        cout<<"Country name is "<<cname<<endl;
    }
};
class District: public State{
    public:
    string dname;
    District(string cn, string sn, string dn):State(cn, sn),dname(dn){};
    virtual void display(){
        cout<<"District name is "<<dname<<endl;
        cout<<"State name is "<<sname<<endl;
        cout<<"Country name is "<<cname<<endl;
    }
}; 
class My_Home: public District{
    public:
    string hname;
    My_Home(string cn, string sn, string dn, string hn):District(cn, sn, dn),hname(hn){};
    virtual void display(){
        cout<<"My_Home name is "<<hname<<endl;
        cout<<"District name is "<<dname<<endl;
        cout<<"State name is "<<sname<<endl;
        cout<<"Country name is "<<cname<<endl;
    }
};
class Union_Territories: public Country{
    public:
    string utname;
    Union_Territories(string cn, string un):Country(cn),utname(un){};
    virtual void display(){
        cout<<"Union_Territories name is "<<utname<<endl;
        cout<<"Country name is "<<cname<<endl;
    }
};
class Friends_Home: public Union_Territories{
    public:
    string fhname;
    Friends_Home(string cn, string un, string fn):Union_Territories(cn, un),fhname(fn){};
    virtual void display(){
        cout<<"Friends_Home name is "<<fhname<<endl;
        cout<<"Union_Territories name is "<<utname<<endl;
        cout<<"Country name is "<<cname<<endl;
    }
};
int main(){
    ns1::check(10, 11, 12);
    ns2::check(6, 7, 8);
    cout << "ns1 same: " << ns1::same << endl;
	cout << "ns2 same: "<< ns2::same << endl;
	cout << "ns1 diff1: " << ns1::diff1 << endl;
	cout << "ns2 diff01: "<< ns2::diff01 << endl;
	cout << "ns1 diff2: " << ns1::diff2 << endl;
	cout << "ns2 diff02: "<< ns2::diff02 << endl;

    cout<<"\n\n\n\n";

    District dist("India", "A.P", "westgodavari");
    Country* coun=dynamic_cast<Country*> (&dist);
    coun->display();
    const type_info &t1=typeid(coun);
    cout<<t1.name()<<endl;

    cout<<"\n\n";

    State* st=&dist;
    st->display();
    const type_info &t2=typeid(st);
    cout<<t2.name()<<endl;

    cout<<"\n\n";

    District* dis=&dist;
    dis->display();
    const type_info &t3=typeid(dis);
    cout<<t3.name()<<endl;

    cout<<"\n\n";
    
    My_Home mh("India", "A.P", "westgodavari", "home");
    My_Home* myh=&mh;
    myh->display();
    const type_info &t4=typeid(myh);
    cout<<t4.name()<<endl;

    cout<<"\n\n\n\n";

    Union_Territories ut("India", "T45");
	Country* c1= dynamic_cast<Country*>(&ut);
	c1->display();
    const type_info &t5=typeid(c1);
    cout<<t5.name()<<endl;

    cout<<"\n\n";

	Friends_Home fh("India", "T45", "sidestreet");
	Country* c2=dynamic_cast<Country*>(&fh);
	c2->display();
    const type_info &t6=typeid(c2);
    cout<<t6.name()<<endl;

    return 0;
}