#include <bits/stdc++.h>
using namespace std;
vector<int> removeDuplicates(vector<int> &arr, int n){
    set<int> s;
    vector<int> v1;
    for(int i=0;i<n;i++){
        s.insert(arr[i]);
    }
    set<int>::iterator it=s.begin();
    for(int i=0;i<s.size();i++){
        v1.push_back(*it);
        it++;
    }
    return v1;
}
int digitSum(int p){
    int sum=0;
     while(p>0){
            int r=p%10;
            sum+=r;
            p/=10;
        }
        return sum;
}
vector<int> removeMultipleDigits(vector<int> &arr){
    vector<int> v2;
    for(int i=0;i<arr.size();i++){
        if(arr[i]> 0 && arr[i]<10){
            v2.push_back(arr[i]);
        }
        else if(arr[i]>9){
            int k=arr[i]; 
            while(k>9){
                 k=digitSum(k);
            }
            v2.push_back(k);
           
        }
    }
    return v2;
    
}
vector<int> rule4(vector<int> &v2, int index){
    
        for(int j=0;j<v2.size()-1;j++){
            for(int k=j+1;k<v2.size();k++){
                if(v2[j]+v2[k]==v2[index]){
                    v2.erase(v2.begin()+index);
                    break;
                }
            }
        }
        return v2;

}
vector<int> rule5(vector<int> &v2, int index){
    int size=v2.size();
    
        for(int j=0;j<size;j++){
             if(v2[j]==sqrt(v2[index])&& index!=j){
                 v2.erase(v2.begin()+index);
                 break;
             }
        }
        return v2;
}
int main(){
    vector<int> v;
    string str;
    cout<<"enter Integers: ";
    getline(cin,str);
    stringstream ss(str);
    string x;
    while (ss >> x) {
        v.push_back(stoi(x));
    }
    int n=v.size();
    for(int i=0;i<n;i++){
        cout<<v[i]<<" ";
    }
    cout<<"\n";
    
    v=removeMultipleDigits(v);
    v=removeDuplicates(v,n);
    for(int i=0;i<v.size();i++){
        v=rule4(v,i);
    }
    for(int i=0;i<v.size();i++){
        v=rule5(v,i);
    }

    cout<<"new: ";
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }

}